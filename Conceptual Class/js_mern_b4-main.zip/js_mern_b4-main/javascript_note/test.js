// console.log("Hello world");
// let age = 25;
// const x = 30;

// age = 26;


// let studentName = "Faisal ahmed";

// let y;
// // console.log("===========>❤", y)

// let person = {
//     firstName: "John",
//     lastName: "Doe",
//     age: 30
// };

// var numbers = [1, 2, 3, 4, 5];

// let newString = `My Name is ${studentName} and my age is ${age}

// . I love javascript. My data is here ${person.firstName} and something from array is ${numbers[2]}

// `
// console.log(newString);



// // console.log("=======>test", typeof person, typeof y, typeof age, typeof studentName, typeof numbers)



// const arr = [1, 2, 3, 4, 5];
// let sum = 0;
// for (let i = 0; i < arr.length; i++) {
// sum += arr[i];
// if (sum >= 10) {
// break;
// }
// }
// console.log(sum);

// const arr = [1, 2, 3, 4, 5];
// const result = arr.reduce((acc, num) => {
//     if (num % 2 === 0) {
//         return acc + num;
//     }
//     return acc;
// }, 0);
// console.log(result);


const obj = {
    prop1: {
        prop2: {
            prop3: 'value'
        }
    }
};

console.log(obj.prop1.prop2.prop3.length);





