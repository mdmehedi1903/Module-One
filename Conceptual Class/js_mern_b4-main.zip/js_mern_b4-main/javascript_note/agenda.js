/**1.How to run javascript file,console.log()
 * 1.1. basic git commands
 * 2. variable, naming convention
 * 3.variable types-number, string,boolean===> typeof, concatenation
 * 4.conversion -parseInt, parseFloat,toFixed
 * 5.Operators ======>
 *   i.  Basic Math operator==> + - * / %
 *   ii. Comparison Operator ===> ==, ===, >, >=,<,<=, !=,!== , strict equality, Loose equality
 *   iii.Logical Operator &&, ||
 * 6.shorthand====> ++,+=5,--,-=10,*=, /=,%=
 * 7.conditionals- if-else, if-else if, if-else if -else
 * 8.multiple conditions==>
 * 9.nested if
 * 10. ternary operator=====> ()?" ":" "
 * 11.switch statement
 * 12.operator precedence 
 * 13.while loop
 * 14. For loop
 * 14.1. continue statement
 * 14.2.break statement
 * 14.3. Debugging in a loop using vscode nodejs environment.
 * 15.Array declaration,get element value by index,set element value by index,find index of an element,array length
 * 16.Add/Remove element from an array====>push,pop,shift,unshift
 * 17.Run a loop for each element of an array /For of loop
 * 18.Declaration of object, set and get object properties, Dot vs Bracket Notation 
 * 19. Object.keys() Object.values() 
 * 20.Looping through an Object / for in loop
 * 21.Function
 * 22.Function Declarations vs. Expressions
 *    
 * */ 